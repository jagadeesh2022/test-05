import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map, skipWhile, tap} from 'rxjs/operators'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServService {
  // croplistddetails: any;

  constructor(private http : HttpClient) { }

  // getData(){
  //   return this.http.get('https://www.pathcarediagnostics.in/api/tests')
  //     .pipe(
  //       map((response:[]) => response.map(item => item['name']))
  //     )
  // }
  croplistddetails()
  {
    return new Promise((resolve , reject) => {
      this.http.get('https://www.pathcarediagnostics.in/api/tests') 
        .subscribe( res => 
           {             
                resolve(res); 
           }, (err) =>
            { 
                 reject(err);
            });
      });  

      }

}
