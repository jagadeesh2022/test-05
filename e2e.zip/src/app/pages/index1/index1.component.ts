import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {ServService} from './serv.service';
import {HostListener} from "@angular/core";

@Component({
  selector: 'app-index1',
  templateUrl: './index1.component.html',
  styleUrls: ['./index1.component.scss']
})

/**
 * Index-1 component
 */
export class Index1Component implements OnInit {

   title = 'autocomplete';

    options = ["Sam", "Varun", "Jasmine"];


    // filteredOptions;


    // formGroup : FormGroup;
    jagadees : any;
    anil : any;
    resdatata : any;
    searchTerm : any;
    croplistde : any;
    filtereditems : any;
    finalvalue : any;
    searchItemName : any;
    Erripuka : any;
    search : any;
    PathcareSearch : any;
    searchPathcareSearch : any;
    some_text = "Click Here";
    inside = false;

  currentSection = 'home';

  constructor(private service : ServService, private fb : FormBuilder) { }


      @HostListener("click")
    clicked() {
        this.inside = true;
    }
    @HostListener("document:click")
    clickedOut() {
        this.finalvalue = [];
    }
    ngOnInit() {
        this.getNames();
    }
    getNames() {
        this.service.croplistddetails().then(res => {
            console.log(res);
            this.resdatata = res;
            this.croplistde = this.resdatata
        });
    }
    onKeyUp(value : any) {
        this.searchTerm = value.target.value;
        if (this.searchTerm) {} else {
            this.finalvalue = [];
        }
        console.log(this.searchTerm);
    }
    filterItems() {
        console.log(this.searchTerm);
        this.filtereditems = this.croplistde;
        this.finalvalue = this.filtereditems.filter((item : any) => {
            return item.TestName.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1;
            console.log(item.TestName.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
        });
    }
    searchItem(item : any) {
        this.jagadees = item.TestName;
        window.location.href = item.TestInfoUrl;
        this.finalvalue = null;

    }






  /**
   * Window scroll method
   */
  windowScroll() {
    const navbar = document.getElementById('navbar');
    if (document.body.scrollTop >= 50 || document.documentElement.scrollTop > 50) {
      navbar.classList.add('nav-sticky');
    } else {
      navbar.classList.remove('nav-sticky');
    }
  }

  /**
   * Section changed method
   * @param sectionId specify the current sectionID
   */
  onSectionChange(sectionId: string) {
    this.currentSection = sectionId;
  }

  /**
   * Toggle navbar
   */
  toggleMenu() {
    document.getElementById('navbarCollapse').classList.toggle('show');
  }
}
