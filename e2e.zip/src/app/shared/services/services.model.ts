export interface Services {
    icon: string;
    title: string;
    text: string;
}
