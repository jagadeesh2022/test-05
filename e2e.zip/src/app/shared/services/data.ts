const serviceData = [
    { icon: 'grid', title: 'Bootstrap UI based', text: 'To an English person, it will seem like English as skeptical.' },
    { icon: 'edit', title: 'Easy to customize', text: 'If several languages coalesce, the grammar of the language.' },
    { icon: 'headphones', title: 'Awesome Support', text: 'The languages only differ in their grammar their pronunciation' },
    { icon: 'layers', title: 'Creative Design', text: 'Everyone realizes why a new common would be desirable.' },
    { icon: 'code', title: 'Quality Code', text: 'To achieve this, it would be necessary to have uniform.' },
    { icon: 'tablet', title: 'Responsive layout', text: 'Their separate existence is a myth. For science, music, etc.' },
];

export { serviceData };
