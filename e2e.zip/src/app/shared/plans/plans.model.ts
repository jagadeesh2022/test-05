export interface Pricing {
    title: string;
    price: number;
    bandwidth: string;
    onlinespace: string;
    support: string;
}
