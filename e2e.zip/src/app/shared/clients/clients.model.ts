export interface Testimonial {
    message: string;
    username: string;
}
